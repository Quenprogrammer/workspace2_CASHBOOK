import { NewsPipePipe } from './news-pipe.pipe';

describe('NewsPipePipe', () => {
  it('create an instance', () => {
    const pipe = new NewsPipePipe();
    expect(pipe).toBeTruthy();
  });
});
