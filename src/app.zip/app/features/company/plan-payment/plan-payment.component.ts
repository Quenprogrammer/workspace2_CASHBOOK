import { Component } from '@angular/core';

@Component({
  selector: 'app-plan-payment',
  standalone: true,
  imports: [],
  templateUrl: './plan-payment.component.html',
  styleUrl: './plan-payment.component.css'
})
export class PlanPaymentComponent {

}
