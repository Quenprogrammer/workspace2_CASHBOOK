import { Component } from '@angular/core';

@Component({
  selector: 'app-clothes',
  standalone: true,
  imports: [],
  templateUrl: './clothes.component.html',
  styleUrl: './clothes.component.css'
})
export class ClothesComponent {

}
