import { Component } from '@angular/core';

@Component({
  selector: 'app-finitures',
  standalone: true,
  imports: [],
  templateUrl: './finitures.component.html',
  styleUrl: './finitures.component.css'
})
export class FinituresComponent {

}
