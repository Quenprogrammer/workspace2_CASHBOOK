import {Component} from '@angular/core';

@Component({
  selector: 'app-debits-records',
  standalone: true,
  imports: [],
  templateUrl: './debits-records.component.html',
  styleUrl: './debits-records.component.scss'
})
export class DebitsRecordsComponent {

}
