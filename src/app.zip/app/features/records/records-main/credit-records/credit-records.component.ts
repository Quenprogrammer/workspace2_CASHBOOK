import {Component} from '@angular/core';

@Component({
  selector: 'app-credit-records',
  standalone: true,
  imports: [],
  templateUrl: './credit-records.component.html',
  styleUrl: './credit-records.component.scss'
})
export class CreditRecordsComponent {

}
