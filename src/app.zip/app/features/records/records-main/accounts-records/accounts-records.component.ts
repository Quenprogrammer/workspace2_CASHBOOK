import {Component} from '@angular/core';

@Component({
  selector: 'app-accounts-records',
  standalone: true,
  imports: [],
  templateUrl: './accounts-records.component.html',
  styleUrl: './accounts-records.component.scss'
})
export class AccountsRecordsComponent {

}
