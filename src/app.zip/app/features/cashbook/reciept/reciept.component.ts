import { Component } from '@angular/core';

@Component({
  selector: 'app-reciept',
  standalone: true,
  imports: [],
  templateUrl: './reciept.component.html',
  styleUrl: './reciept.component.css'
})
export class RecieptComponent {

}
