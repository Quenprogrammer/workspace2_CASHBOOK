import { Component } from '@angular/core';

@Component({
  selector: 'app-backup-data-password',
  standalone: true,
  imports: [],
  templateUrl: './backup-data-password.component.html',
  styleUrl: './backup-data-password.component.css'
})
export class BackupDataPasswordComponent {

}
