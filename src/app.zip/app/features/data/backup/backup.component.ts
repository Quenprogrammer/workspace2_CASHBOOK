import { Component } from '@angular/core';
import {Observable} from 'rxjs';
import { BackupService } from '../../../services/backup.service';
@Component({
  selector: 'app-backup',
  standalone: true,
  imports: [],
  templateUrl: './backup.component.html',
  styleUrl: './backup.component.css'
})
export class BackupComponent {

}
