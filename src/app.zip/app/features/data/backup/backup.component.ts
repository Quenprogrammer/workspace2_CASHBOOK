import { Component } from '@angular/core';

@Component({
  selector: 'app-backup',
  standalone: true,
  imports: [],
  templateUrl: './backup.component.html',
  styleUrl: './backup.component.css'
})
export class BackupComponent {

}
