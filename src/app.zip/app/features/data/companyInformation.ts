
export const companyName = "SAHIZ GROUP";
export const industry = "Technology";
export const address = " Danladi Nasidi Estate Mariri Kano";
export const founded = "2019";
export const headquarters = "Kano State, Kumbotso";

export const website = "https://www.techinnovations.com";
export const CEOName = "Abdullahi Sidi Jinjiri";

export const email = "info@techinnovations.com";
export const phone = "+9036014519";

export const socialAccount = [

  {name:'Discord', link:'',logo:'socialIcons/4.png'},
  {name:'Facebook', link:'',logo:'socialIcons/5.png'},
  {name:'GitHub', link:'',logo:'socialIcons/6.png'},


  {name:'Instagram', link:'',logo:'socialIcons/9.png'},
  {name:'LinkedIn', link:'',logo:'socialIcons/10.png'},
  {name:'Reddit', link:'',logo:'socialIcons/14.png'},
  {name:'Snapchat', link:'',logo:'socialIcons/15.png'},
  {name:'Telegram', link:'',logo:'socialIcons/16.png'},
  {name:'Tiktok', link:'',logo:'socialIcons/17.png'},
  {name:'Youtube', link:'',logo:'socialIcons/24.png'},
]
export const paymentMethods=[
  {name:'Instagram', logo:'',Details:{}},
  {name:'Instagram', logo:'',Details:{}},
  {name:'Instagram', logo:'',Details:{}},
]
