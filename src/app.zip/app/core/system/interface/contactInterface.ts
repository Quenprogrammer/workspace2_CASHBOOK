export interface MessageInquiries {

  date: string;
  additionalInformation: string;
  name: string;
  phoneNumber: number;
  Email: string;
  socialMedia: string;
}
