export const headingTextColor='red';
export const textColor='white';
export const textFontSize='white';
export const headingFontSize='white';
export const backgroundColor='white';
