import { Component } from '@angular/core';

@Component({
  selector: 'app-vault-password',
  standalone: true,
  imports: [],
  templateUrl: './vault-password.component.html',
  styleUrl: './vault-password.component.css'
})
export class VaultPasswordComponent {

}
