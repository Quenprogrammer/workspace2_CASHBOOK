import { Component } from '@angular/core';

@Component({
  selector: 'app-setup-payment',
  standalone: true,
  imports: [],
  templateUrl: './setup-payment.component.html',
  styleUrl: './setup-payment.component.css'
})
export class SetupPaymentComponent {

}
