export const fail:string='Operation Failed';
export const pass:string='Operation successful';
