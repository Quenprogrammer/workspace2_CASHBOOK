import { Component } from '@angular/core';

@Component({
  selector: 'app-start-up',
  standalone: true,
  imports: [],
  templateUrl: './start-up.component.html',
  styleUrl: './start-up.component.css'
})
export class StartUpComponent {

}
