import {Component} from '@angular/core';

@Component({
    selector: 'app-aims-tag',
    standalone: true,
    imports: [],
    templateUrl: './aims-tag.component.html',
    styleUrl: './aims-tag.component.css'
})
export class AimsTagComponent {

}
