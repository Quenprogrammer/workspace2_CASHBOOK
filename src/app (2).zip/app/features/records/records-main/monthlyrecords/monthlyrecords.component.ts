import {Component} from '@angular/core';

@Component({
  selector: 'app-monthlyrecords',
  standalone: true,
  imports: [],
  templateUrl: './monthlyrecords.component.html',
  styleUrl: './monthlyrecords.component.scss'
})
export class MonthlyrecordsComponent {

}
