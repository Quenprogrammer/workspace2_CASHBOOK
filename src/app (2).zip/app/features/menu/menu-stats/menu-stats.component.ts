import {Component} from '@angular/core';

@Component({
  selector: 'app-menu-stats',
  standalone: true,
  imports: [],
  templateUrl: './menu-stats.component.html',
  styleUrl: './menu-stats.component.css'
})
export class MenuStatsComponent {

}
