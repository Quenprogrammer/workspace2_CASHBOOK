import { LineBreakPipe } from './line-break.pipe';

describe('LineBreakPipe', () => {
  it('create an instance', () => {
    const pipe = new LineBreakPipe();
    expect(pipe).toBeTruthy();
  });
});
