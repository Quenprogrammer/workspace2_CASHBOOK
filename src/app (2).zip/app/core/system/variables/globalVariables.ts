
export const totalStorage: number = 1000000;
export const crypto:string='apps/crypto/'
export const path:string='apps/'
export const payment:string='apps/payment/'



