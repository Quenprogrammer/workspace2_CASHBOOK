This folder contains our front bootstrap template.

You can edit the template and change colors
